<header class="et-header">
    
    <div class="et-topbar">
        <div class="et-container et-topbar-inner">
            <div class="et-topbar-left">
                <span><i class="bi bi-shield-check"></i> 100% Thiết Bị Chính Hãng VN/A</span>
                <span class="et-top-divider">|</span>
                <span><i class="bi bi-truck"></i> Giao Hỏa Tốc 2 giờ nội thành</span>
            </div>

            <div class="et-topbar-right">
                <span><i class="bi bi-telephone"></i> Hotline: 1800.6868 (Miễn phí)</span>
            </div>
        </div>
    </div>

    
    <div class="et-main-header">
        <div class="et-container et-main-header-inner">

            <a href="<?php echo e(url('/')); ?>" class="et-logo">
                <span class="et-logo-icon">
                    <i class="bi bi-cpu"></i>
                </span>
                <span class="et-logo-text">
                    <strong>Electro<span>Tech</span></strong>
                    <small>ELECTRONICS STORE</small>
                </span>
            </a>

            <form action="<?php echo e(url('/products')); ?>" method="GET" class="et-search">
                <i class="bi bi-search"></i>
                <input type="search" name="search" placeholder="Tìm iPhone 16 Pro Max, MacBook M3, Sony XM5, Bàn phím"
                    aria-label="Tìm kiếm sản phẩm">
                <button type="submit">Tìm kiếm</button>
            </form>

            <a href="/notifications" class="et-header-icon" aria-label="Thông báo">
                <i class="bi bi-bell"></i>
                <span class="et-notification-dot">2</span>
            </a>

            <a href="<?php echo e(url('/cart')); ?>" class="et-cart">
                <i class="bi bi-cart3"></i>
                <span>Giỏ hàng</span>
                <b>1</b>
            </a>


            <div class="et-account-wrapper">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                    
                    <?php
                        $user = Auth::user();
                    ?>

                    <button type="button" class="et-account" id="etAccountToggle" aria-expanded="false"
                        aria-controls="etAccountDropdown">

                        <span class="et-avatar">
                            <i class="bi bi-person-fill"></i>
                        </span>

                        <span class="et-account-text">
                            <strong><?php echo e($user->fullname); ?></strong>
                            <small>Tech VIP</small>
                        </span>

                        <i class="bi bi-chevron-down et-account-chevron"></i>
                    </button>

                    <div class="et-account-dropdown" id="etAccountDropdown">

                        <div class="et-dropdown-profile">
                            <strong><?php echo e($user->fullname); ?></strong>
                            <span><?php echo e($user->email); ?></span>

                            <div class="et-vip-info">
                                <span>Tech VIP</span>
                                <strong>1.250 điểm</strong>
                            </div>
                        </div>
                        <div class="et-dropdown-links">
                            <a href="<?php echo e(url('/account/profile')); ?>">
                                <i class="bi bi-person"></i>
                                <span>Thông tin tài khoản</span>
                            </a>

                            <a href="<?php echo e(url('/orders')); ?>">
                                <i class="bi bi-box-seam"></i>
                                <span>Quản lý đơn hàng</span>
                            </a>

                            <a href="<?php echo e(url('/notifications')); ?>">
                                <i class="bi bi-bell"></i>
                                <span>Thông báo</span>
                            </a>
                        </div>

                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit">Đăng xuất</button>
                        </form>

                    </div>
                <?php else: ?>
                    
                    <div class="et-account">
                        <span class="et-avatar">
                            <i class="bi bi-person-fill"></i>
                        </span>

                        <span class="et-account-text">
                            <a href="<?php echo e(url('/login')); ?>">
                                <strong>Đăng nhập</strong>
                            </a>
                            <small>
                                <a href="<?php echo e(url('/register')); ?>">Đăng ký tài khoản</a>
                            </small>
                        </span>
                    </div>

                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            </div>
        </div>
    </div>


    
    <nav class="et-category-nav">
        <div class="et-container et-category-inner" id="categoryMenu">

            <a href="/products">Tất cả sản phẩm</a>

            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <a href="<?php echo e(url('/products?category=' . $category->category_id)); ?>"
                    class="category-nav-item <?php echo e($loop->iteration > 6 ? 'category-hidden' : ''); ?>">
                    <?php echo e($category->name); ?>

                </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

            
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($categories->count() > 6): ?>
                <button type="button" id="toggleCategories" class="category-toggle">
                    Xem thêm <i class="bi bi-chevron-down"></i>
                </button>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <div class="et-nav-spacer"></div>

            <a href="/products" class="et-nav-active">Tất cả sản phẩm</a>
            <a href="/orders">Đơn hàng của tôi</a>

        </div>
    </nav>

    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const menu = document.getElementById('categoryMenu');
            const toggleButton = document.getElementById('toggleCategories');

            if (!menu || !toggleButton) return;

            toggleButton.addEventListener('click', function() {
                const expanded = menu.classList.toggle('categories-expanded');

                toggleButton.innerHTML = expanded ?
                    'Thu gọn <i class="bi bi-chevron-up"></i>' :
                    'Xem thêm <i class="bi bi-chevron-down"></i>';
            });
        });
    </script>

</header>
<?php /**PATH D:\all\FPT POLYTECHNIC\Dự án tốt nghiệp\CODE\Technology\resources\views/layouts/header.blade.php ENDPATH**/ ?>