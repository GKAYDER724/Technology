<?php $__env->startSection('title', 'ElectroTech | Siêu thị công nghệ chính hãng'); ?>

<?php $__env->startSection('content'); ?>
    <div class="tech-home">

        
        <section class="tech-hero">
            <div class="hero-copy">
                <span class="hero-tag">
                    <i class="bi bi-lightning-charge-fill"></i>
                    Sản phẩm tiên phong công nghệ 2026
                </span>

                <h1>
                    iPhone 16 Pro Max
                    <span>Titan Siêu Nhẹ. Chip A18 Pro.</span>
                </h1>

                <p>
                    Nút Camera Control hoàn toàn mới, màn hình Super Retina XDR
                    6.9 inch viền siêu mỏng, thời lượng pin bền bỉ đến 33 giờ.
                    Hàng chính hãng VN/A sẵn sàng giao ngay.
                </p>

                <div class="hero-price">
                    <strong>33.490.000₫</strong>
                    <del>35.990.000₫</del>
                    <span>Tiết kiệm 2.500.000₫</span>
                </div>

                <div class="hero-actions">
                    <a href="/products/1" class="tech-btn">
                        Xem chi tiết &amp; Mua ngay
                        <i class="bi bi-arrow-right"></i>
                    </a>
                    <a href="/products" class="tech-btn tech-btn-dark">
                        Khám phá toàn bộ thiết bị
                    </a>
                </div>

                <div class="hero-promises">
                    <span><i class="bi bi-check-circle"></i> Bảo hành 12 tháng</span>
                    <span><i class="bi bi-check-circle"></i> Trả góp 0% lãi suất</span>
                    <span><i class="bi bi-check-circle"></i> Đổi mới 30 ngày</span>
                </div>
            </div>

            <div class="hero-visual">
                <img src="https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=900&q=85"
                    alt="iPhone 16 Pro Max">
                <div class="hero-product-label">
                    <div>
                        <strong>Titan Sa Mạc (Desert Titanium)</strong>
                        <small>Cao cấp hơn. Nhẹ hơn. Thời thượng.</small>
                    </div>
                    <span>Còn 24 máy</span>
                </div>
            </div>
        </section>

        
        <section class="tech-section">
            <div class="section-heading">
                <div>
                    <h2>Danh Mục Thiết Bị Nổi Bật</h2>
                    <p>Khám phá các dòng sản phẩm công nghệ cao cấp chính hãng</p>
                </div>
                <a href="/products">Tất cả danh mục <i class="bi bi-chevron-right"></i></a>
            </div>


            <div class="category-grid" id="homeCategoryGrid">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <a href="<?php echo e(url('/products?category=' . $category->category_id)); ?>"
                        class="category-item <?php echo e($loop->iteration > 6 ? 'category-hidden' : ''); ?>">

                        <span class="category-icon">
                            <i class="bi bi-cpu"></i>
                        </span>

                        <strong><?php echo e($category->name); ?></strong>
                        <small>Khám phá sản phẩm</small>
                    </a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($categories->count() > 6): ?>
                <div class="category-more-wrapper">
                    <button type="button" id="toggleHomeCategories" class="category-toggle">
                        Xem thêm <i class="bi bi-chevron-down"></i>
                    </button>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        </section>


        
        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($flashSaleProducts) && $flashSaleProducts->count() > 0): ?>
            <section class="flashsale-section">

                <div class="flashsale-heading">
                    <div class="flashsale-title">
                        <span class="flashsale-icon">
                            <i class="bi bi-fire"></i>
                        </span>

                        <div>
                            <h2>FLASH SALE GIÁ SỐC</h2>
                            <p>Cơ hội săn deal công nghệ giảm tới 30%!</p>
                        </div>

                        <span class="flashsale-today">ƯU ĐÃI ĐẶC BIỆT</span>
                    </div>

                    <div class="flashsale-count">
                        <i class="bi bi-lightning-charge-fill"></i>
                        SẢN PHẨM ĐANG GIẢM GIÁ
                    </div>
                </div>

                <div class="sale-carousel">
                    <div class="sale-grid" id="saleGrid">

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $flashSaleProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <?php
                                $discount = round(
                                    (($product->base_price - $product->sale_price) / $product->base_price) * 100,
                                );
                            ?>

                            <article class="sale-card">

                                <div class="sale-image">

                                    <span class="discount-badge">
                                        -<?php echo e($discount); ?>%
                                    </span>

                                    <img src="<?php echo e($product->product_image ? asset('storage/' . $product->product_image) : asset('images/no-image.png')); ?>"
                                        alt="<?php echo e($product->name); ?>" loading="lazy">
                                </div>

                                <div class="sale-content">

                                    <small>FLASH SALE</small>

                                    <h3><?php echo e($product->name); ?></h3>

                                    <div class="sale-price">
                                        <?php echo e(number_format($product->sale_price, 0, ',', '.')); ?>₫

                                        <del>
                                            <?php echo e(number_format($product->base_price, 0, ',', '.')); ?>₫
                                        </del>
                                    </div>

                                    <div class="sale-actions">

                                        <a href="<?php echo e(url('/products/' . $product->product_id)); ?>">
                                            Chi tiết
                                        </a>

                                        <a href="<?php echo e(url('/cart')); ?>" aria-label="Xem giỏ hàng">
                                            <i class="bi bi-cart3"></i>
                                        </a>

                                    </div>

                                </div>

                            </article>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

                    </div>
                </div>

            </section>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <section class="tech-section">
            <div class="section-heading">
                <div>
                    <h2>Sản Phẩm Bán Chạy Nhất <span class="top-label">Top Đánh Giá</span></h2>
                    <p>Những công nghệ được khách hàng tin tưởng lựa chọn</p>
                </div>
                <a href="/products">Xem tất cả <i class="bi bi-chevron-right"></i></a>
            </div>

            <div class="best-grid">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <article class="best-card">
                        <div class="best-image">
                            <img src="<?php echo e($product->product_image ? asset($product->product_image) : asset('images/no-image.png')); ?>"
                                alt="<?php echo e($product->name); ?>" loading="lazy">
                        </div>

                        <div class="best-content">
                            <h3><?php echo e($product->name); ?></h3>

                            <div class="best-price">
                                <?php echo e(number_format($product->sale_price ?? $product->base_price, 0, ',', '.')); ?>₫
                            </div>

                            <div class="best-bottom">
                                <span>Còn <?php echo e($product->stock); ?> trong kho</span>

                                <a href="<?php echo e(url('/products/' . $product->product_id)); ?>">
                                    🛒 Mua ngay
                                </a>
                            </div>
                        </div>
                    </article>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <p>Chưa có sản phẩm nào.</p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </section>

        
        <section class="promo-grid">
            <a href="/products?category=laptop" class="promo-card promo-laptop">
                <div>
                    <small>CẤU HÌNH ĐỈNH CAO</small>
                    <h2>MacBook M3 Pro &amp; ASUS ROG RTX 4070</h2>
                    <p>Trải nghiệm hiệu năng đỉnh cao, thiết kế không dây giới hạn.</p>
                    <span>Xem các dòng Laptop <i class="bi bi-arrow-right"></i></span>
                </div>
                <img src="https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=500&q=85"
                    alt="Laptop cao cấp">
            </a>

            <a href="/products?category=audio" class="promo-card promo-audio">
                <div>
                    <small>TRẢI NGHIỆM ÂM THANH CHUẨN</small>
                    <h2>Sony WH-1000XM5 &amp; Marshall Stanmore III</h2>
                    <p>Nhập mã TECH500 giảm ngay 500.000₫.</p>
                    <span>Khám phá Loa &amp; Tai nghe <i class="bi bi-arrow-right"></i></span>
                </div>
                <img src="https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=500&q=85"
                    alt="Tai nghe cao cấp">
            </a>
        </section>

        
        <section class="trust-section">
            <div class="trust-heading">
                <h2>Cam Kết Chất Lượng Tại ElectroTech</h2>
                <p>Trải nghiệm mua sắm an tâm với chính sách bảo hành và hỗ trợ số 1</p>
            </div>

            <div class="trust-grid">
                <div class="trust-item">
                    <span class="trust-icon blue"><i class="bi bi-shield-check"></i></span>
                    <strong>Chính Hãng 100%</strong>
                    <small>Đầy đủ VAT &amp; CO/CQ</small>
                </div>
                <div class="trust-item">
                    <span class="trust-icon green"><i class="bi bi-truck"></i></span>
                    <strong>Giao Tốc Hành 2H</strong>
                    <small>Nội thành HN &amp; TP.HCM</small>
                </div>
                <div class="trust-item">
                    <span class="trust-icon orange"><i class="bi bi-arrow-repeat"></i></span>
                    <strong>Đổi Mới 30 Ngày</strong>
                    <small>Lỗi phần cứng đổi ngay</small>
                </div>
                <div class="trust-item">
                    <span class="trust-icon purple"><i class="bi bi-lightning-charge"></i></span>
                    <strong>Tích Điểm Tech VIP</strong>
                    <small>Quy đổi voucher tri ân</small>
                </div>
            </div>
        </section>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const categoryGrid = document.getElementById('homeCategoryGrid');
            const toggleButton = document.getElementById('toggleHomeCategories');

            if (!categoryGrid || !toggleButton) return;

            // Đảm bảo lúc tải trang luôn ở trạng thái thu gọn
            categoryGrid.classList.remove('categories-expanded');

            toggleButton.innerHTML =
                'Xem thêm <i class="bi bi-chevron-down"></i>';

            toggleButton.addEventListener('click', function() {
                const expanded = categoryGrid.classList.toggle('categories-expanded');

                toggleButton.innerHTML = expanded ?
                    'Thu gọn <i class="bi bi-chevron-up"></i>' :
                    'Xem thêm <i class="bi bi-chevron-down"></i>';
            });

            const grid = document.getElementById('saleGrid');

            if (!grid) return;

            const cards = grid.querySelectorAll('.sale-card');

            // Không chạy slide nếu có tối đa 4 sản phẩm
            if (cards.length <= 4) return;

            let currentIndex = 0;
            let interval;

            function getVisibleCards() {
                if (window.innerWidth <= 576) return 1;
                if (window.innerWidth <= 992) return 2;
                return 4;
            }

            function moveSlide() {
                const visibleCards = getVisibleCards();
                const maxIndex = cards.length - visibleCards;

                currentIndex++;

                if (currentIndex > maxIndex) {
                    currentIndex = 0;
                }

                const cardWidth = cards[0].offsetWidth;
                const gap = 20;

                grid.style.transform =
                    `translateX(-${currentIndex * (cardWidth + gap)}px)`;
            }

            function startSlide() {
                clearInterval(interval);

                if (cards.length > getVisibleCards()) {
                    interval = setInterval(moveSlide, 3000);
                }
            }

            window.addEventListener('resize', function() {
                currentIndex = 0;
                grid.style.transform = 'translateX(0)';
                startSlide();
            });

            startSlide();

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\all\FPT POLYTECHNIC\Dự án tốt nghiệp\CODE\Technology\resources\views/home.blade.php ENDPATH**/ ?>